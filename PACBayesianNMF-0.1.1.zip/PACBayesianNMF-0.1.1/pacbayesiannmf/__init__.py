# -*- coding: utf-8 -*-
"""
Created on Mon Jul 04 14:15:39 2016

@author: astha
"""
__version__ = "0.1.0"
from blockGradientDescent import *